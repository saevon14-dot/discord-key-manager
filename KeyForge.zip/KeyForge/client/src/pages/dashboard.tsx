import { useState } from "react";
import Sidebar from "@/components/dashboard/sidebar";
import Header from "@/components/dashboard/header";
import DashboardTab from "@/components/dashboard/dashboard-tab";
import KeysTab from "@/components/dashboard/keys-tab";
import RolesTab from "@/components/dashboard/roles-tab";
import BotTab from "@/components/dashboard/bot-tab";
import LogsTab from "@/components/dashboard/logs-tab";
import GitHubPagesNotice from "@/components/github-pages-notice";
import { useWebSocket } from "@/hooks/use-websocket";
import { useWebSocketPages } from "@/hooks/use-websocket-pages";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("dashboard");

  // Use appropriate connection method
  const connectionType = useWebSocketPages();
  
  // Set up WebSocket for real-time updates (only when not on GitHub Pages)
  if (connectionType === 'websocket') {
    useWebSocket({
      onMessage: (data) => {
        // Handle real-time updates
        console.log("WebSocket message:", data);
      },
    });
  }

  const renderTabContent = () => {
    switch (activeTab) {
      case "dashboard":
        return <DashboardTab />;
      case "keys":
        return <KeysTab />;
      case "roles":
        return <RolesTab />;
      case "bot":
        return <BotTab />;
      case "logs":
        return <LogsTab />;
      default:
        return <DashboardTab />;
    }
  };

  const getTabInfo = (tab: string) => {
    const tabInfo = {
      dashboard: { title: "Dashboard", description: "Monitor your bot's activity and manage keys" },
      keys: { title: "Key Management", description: "Add, remove, and organize your key pools" },
      roles: { title: "Role Settings", description: "Configure authorized roles and permissions" },
      bot: { title: "Bot Configuration", description: "Configure your Discord bot settings" },
      logs: { title: "Activity Logs", description: "View recent bot activity and events" },
    };
    return tabInfo[tab as keyof typeof tabInfo] || tabInfo.dashboard;
  };

  return (
    <div className="dark min-h-screen flex h-screen">
      <GitHubPagesNotice />
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
      <div className="flex-1 overflow-hidden">
        <Header tabInfo={getTabInfo(activeTab)} />
        <main className="p-6 overflow-y-auto h-full">
          {renderTabContent()}
        </main>
      </div>
    </div>
  );
}
