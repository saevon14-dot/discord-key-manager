// GitHub Pages API Client - Works with external APIs or mock data
const IS_GITHUB_PAGES = window.location.hostname.includes('github.io');
const API_BASE = IS_GITHUB_PAGES 
  ? 'https://api.github.com' // Fallback API or your own serverless functions
  : '';

export class GitHubPagesApiClient {
  private mockData = {
    botStatus: {
      online: false,
      uptime: 0,
      serverCount: 0,
      latency: -1,
      lastStarted: new Date().toISOString()
    },
    dashboardStats: {
      totalKeys: 0,
      todayGenerated: 0,
      activeRoles: 0,
      uptime: 0,
      keyPools: {
        day: 0,
        week: 0,
        month: 0,
        '3month': 0,
        '6month': 0,
        lifetime: 0,
        custom: 0
      }
    },
    roles: [] as any[],
    keys: [] as any[],
    settings: [] as any[],
    logs: [] as any[]
  };

  private storage = {
    get: (key: string) => {
      const data = localStorage.getItem(`discord-keys-${key}`);
      return data ? JSON.parse(data) : null;
    },
    set: (key: string, value: any) => {
      localStorage.setItem(`discord-keys-${key}`, JSON.stringify(value));
    }
  };

  async request(endpoint: string, options: RequestInit = {}) {
    if (!IS_GITHUB_PAGES) {
      // Use normal API when not on GitHub Pages
      const response = await fetch(`/api${endpoint}`, options);
      if (!response.ok) throw new Error(`API Error: ${response.status}`);
      return response.json();
    }

    // GitHub Pages mode - use localStorage for persistence
    const method = options.method || 'GET';
    const [, resource, action] = endpoint.split('/');

    switch (method) {
      case 'GET':
        return this.handleGet(resource, action, endpoint);
      case 'POST':
        return this.handlePost(resource, action, options.body as string);
      case 'DELETE':
        return this.handleDelete(resource, action, endpoint);
      default:
        return this.mockData;
    }
  }

  private handleGet(resource: string, action?: string, fullEndpoint?: string) {
    switch (resource) {
      case 'bot':
        if (action === 'status') {
          const stored = this.storage.get('botStatus');
          return stored || this.mockData.botStatus;
        }
        break;
      
      case 'dashboard':
        if (action === 'stats') {
          const stored = this.storage.get('dashboardStats');
          return stored || this.mockData.dashboardStats;
        }
        break;
      
      case 'roles':
        return this.storage.get('roles') || this.mockData.roles;
      
      case 'keys':
        const keys = this.storage.get('keys') || this.mockData.keys;
        if (fullEndpoint?.includes('type=')) {
          const type = fullEndpoint.split('type=')[1];
          return keys.filter((key: any) => key.type === type);
        }
        return keys;
      
      case 'settings':
        return this.storage.get('settings') || this.mockData.settings;
      
      case 'logs':
        return this.storage.get('logs') || this.mockData.logs;
      
      default:
        return {};
    }
  }

  private handlePost(resource: string, action?: string, body?: string) {
    const data = body ? JSON.parse(body) : {};
    
    switch (resource) {
      case 'bot':
        if (action === 'start') {
          const botStatus = {
            ...this.mockData.botStatus,
            online: true,
            lastStarted: new Date().toISOString()
          };
          this.storage.set('botStatus', botStatus);
          return { success: true, message: 'Bot started successfully (GitHub Pages Demo)' };
        }
        if (action === 'stop') {
          const botStatus = { ...this.mockData.botStatus, online: false };
          this.storage.set('botStatus', botStatus);
          return { success: true, message: 'Bot stopped successfully (GitHub Pages Demo)' };
        }
        break;
      
      case 'roles':
        const roles = this.storage.get('roles') || [];
        const newRole = {
          id: Math.random().toString(36).substr(2, 9),
          ...data,
          createdAt: new Date().toISOString()
        };
        roles.push(newRole);
        this.storage.set('roles', roles);
        return newRole;
      
      case 'keys':
        const keys = this.storage.get('keys') || [];
        const newKeys = data.keys.map((keyData: any) => ({
          id: Math.random().toString(36).substr(2, 9),
          ...keyData,
          status: 'available',
          createdAt: new Date().toISOString(),
          usedAt: null,
          usedBy: null
        }));
        keys.push(...newKeys);
        this.storage.set('keys', keys);
        return newKeys;
      
      case 'settings':
        const settings = this.storage.get('settings') || [];
        const existingIndex = settings.findIndex((s: any) => s.key === data.key);
        const setting = {
          id: Math.random().toString(36).substr(2, 9),
          ...data,
          updatedAt: new Date().toISOString()
        };
        
        if (existingIndex >= 0) {
          settings[existingIndex] = setting;
        } else {
          settings.push(setting);
        }
        this.storage.set('settings', settings);
        return setting;
      
      default:
        return { success: true };
    }
  }

  private handleDelete(resource: string, action?: string, endpoint?: string) {
    switch (resource) {
      case 'keys':
        const keyId = endpoint?.split('/').pop();
        if (keyId) {
          const keys = this.storage.get('keys') || [];
          const filteredKeys = keys.filter((key: any) => key.id !== keyId);
          this.storage.set('keys', filteredKeys);
          return { success: true };
        }
        break;
      
      case 'roles':
        const roleId = endpoint?.split('/').pop();
        if (roleId) {
          const roles = this.storage.get('roles') || [];
          const filteredRoles = roles.filter((role: any) => role.id !== roleId);
          this.storage.set('roles', filteredRoles);
          return { success: true };
        }
        break;
      
      default:
        return { success: true };
    }
  }
}

export const apiClient = new GitHubPagesApiClient();