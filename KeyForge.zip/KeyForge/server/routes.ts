import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { discordBot } from "./discord-bot";
import { insertKeySchema, insertRoleSchema, insertSettingSchema, KeyType } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  const connectedClients = new Set<WebSocket>();

  wss.on("connection", (ws) => {
    connectedClients.add(ws);
    console.log("Client connected to WebSocket");

    ws.on("close", () => {
      connectedClients.delete(ws);
      console.log("Client disconnected from WebSocket");
    });
  });

  // Broadcast function for real-time updates
  const broadcast = (data: any) => {
    const message = JSON.stringify(data);
    connectedClients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  };

  // Set up bot status change callback
  discordBot.setStatusChangeCallback((status) => {
    broadcast({ type: "bot_status", data: status });
  });

  // Dashboard stats endpoint
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch dashboard stats" });
    }
  });

  // Keys endpoints
  app.get("/api/keys", async (req, res) => {
    try {
      const { type } = req.query;
      const keys = await storage.getKeys(type as KeyType);
      res.json(keys);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch keys" });
    }
  });

  app.post("/api/keys", async (req, res) => {
    try {
      const { type, customName, keys: keyStrings } = req.body;
      
      if (!keyStrings || !Array.isArray(keyStrings) || keyStrings.length === 0) {
        return res.status(400).json({ error: "Keys array is required" });
      }

      const keysToAdd = keyStrings.map(key => ({
        key: key.trim(),
        type,
        customName: type === "custom" ? customName : undefined,
        status: "available" as const,
      }));

      // Validate each key
      for (const keyData of keysToAdd) {
        insertKeySchema.parse(keyData);
      }

      const addedKeys = await storage.addKeys(keysToAdd);
      
      await storage.addActivityLog({
        type: "keys_added",
        message: `Added ${addedKeys.length} ${type} keys`,
        details: { keyType: type, count: addedKeys.length },
      });

      broadcast({ type: "keys_updated", data: { type, action: "added", count: addedKeys.length } });
      
      res.json(addedKeys);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid key data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to add keys" });
    }
  });

  app.delete("/api/keys/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.removeKey(id);
      
      if (success) {
        await storage.addActivityLog({
          type: "key_removed",
          message: "Key removed",
          details: { keyId: id },
        });

        broadcast({ type: "key_removed", data: { keyId: id } });
        res.json({ success: true });
      } else {
        res.status(404).json({ error: "Key not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to remove key" });
    }
  });

  app.post("/api/keys/cleanup", async (req, res) => {
    try {
      const removed = await storage.removeExpiredKeys();
      
      await storage.addActivityLog({
        type: "keys_cleanup",
        message: `Removed ${removed} expired keys`,
        details: { count: removed },
      });

      broadcast({ type: "keys_cleanup", data: { removed } });
      
      res.json({ removed });
    } catch (error) {
      res.status(500).json({ error: "Failed to cleanup keys" });
    }
  });

  // Roles endpoints
  app.get("/api/roles", async (req, res) => {
    try {
      const roles = await storage.getRoles();
      res.json(roles);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch roles" });
    }
  });

  app.post("/api/roles", async (req, res) => {
    try {
      const roleData = insertRoleSchema.parse(req.body);
      const role = await storage.addRole(roleData);
      
      await storage.addActivityLog({
        type: "role_added",
        message: `Added role ${roleData.roleName}`,
        details: { roleId: roleData.roleId, roleName: roleData.roleName },
      });

      broadcast({ type: "role_added", data: role });
      
      res.json(role);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid role data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to add role" });
    }
  });

  app.put("/api/roles/:roleId", async (req, res) => {
    try {
      const { roleId } = req.params;
      const updates = req.body;
      
      const role = await storage.updateRole(roleId, updates);
      
      if (role) {
        await storage.addActivityLog({
          type: "role_updated",
          message: `Updated role ${role.roleName}`,
          details: { roleId, updates },
        });

        broadcast({ type: "role_updated", data: role });
        res.json(role);
      } else {
        res.status(404).json({ error: "Role not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to update role" });
    }
  });

  app.delete("/api/roles/:roleId", async (req, res) => {
    try {
      const { roleId } = req.params;
      const success = await storage.removeRole(roleId);
      
      if (success) {
        await storage.addActivityLog({
          type: "role_removed",
          message: `Removed role`,
          details: { roleId },
        });

        broadcast({ type: "role_removed", data: { roleId } });
        res.json({ success: true });
      } else {
        res.status(404).json({ error: "Role not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to remove role" });
    }
  });

  // Settings endpoints
  app.get("/api/settings", async (req, res) => {
    try {
      const settings = await storage.getSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  app.post("/api/settings", async (req, res) => {
    try {
      const settingData = insertSettingSchema.parse(req.body);
      const setting = await storage.setSetting(settingData);
      
      broadcast({ type: "setting_updated", data: setting });
      
      res.json(setting);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid setting data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to update setting" });
    }
  });

  // Bot endpoints
  app.post("/api/bot/start", async (req, res) => {
    try {
      const { token } = req.body;
      
      if (!token) {
        return res.status(400).json({ error: "Bot token is required" });
      }

      const success = await discordBot.start(token);
      
      if (success) {
        res.json({ success: true, message: "Bot started successfully" });
      } else {
        res.status(400).json({ error: "Failed to start bot. Please check your token." });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to start bot" });
    }
  });

  app.post("/api/bot/stop", async (req, res) => {
    try {
      await discordBot.stop();
      res.json({ success: true, message: "Bot stopped successfully" });
    } catch (error) {
      res.status(500).json({ error: "Failed to stop bot" });
    }
  });

  app.get("/api/bot/status", async (req, res) => {
    try {
      const status = await storage.getBotStatus();
      res.json(status);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch bot status" });
    }
  });

  // Activity logs endpoint
  app.get("/api/logs", async (req, res) => {
    try {
      const { limit } = req.query;
      const logs = await storage.getActivityLogs(limit ? parseInt(limit as string) : undefined);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch activity logs" });
    }
  });

  return httpServer;
}
