import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const keys = pgTable("keys", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  key: text("key").notNull().unique(),
  type: text("type").notNull(), // day, week, month, 3month, 6month, lifetime, custom
  customName: text("custom_name"), // for custom type
  status: text("status").notNull().default("available"), // available, used
  createdAt: timestamp("created_at").notNull().defaultNow(),
  usedAt: timestamp("used_at"),
  usedBy: text("used_by"),
});

export const roles = pgTable("roles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roleId: text("role_id").notNull().unique(),
  roleName: text("role_name").notNull(),
  permissions: jsonb("permissions").notNull(), // { day: boolean, week: boolean, etc. }
  isAdmin: boolean("is_admin").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const settings = pgTable("settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const activityLogs = pgTable("activity_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // key_generated, role_added, bot_started, etc.
  message: text("message").notNull(),
  details: jsonb("details"),
  userId: text("user_id"),
  userName: text("user_name"),
  serverId: text("server_id"),
  channelId: text("channel_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Insert schemas
export const insertKeySchema = createInsertSchema(keys).omit({
  id: true,
  createdAt: true,
  usedAt: true,
  usedBy: true,
}).extend({
  status: z.literal("available").default("available")
});

export const insertRoleSchema = createInsertSchema(roles).omit({
  id: true,
  createdAt: true,
}).extend({
  isAdmin: z.boolean().default(false)
});

export const insertSettingSchema = createInsertSchema(settings).omit({
  id: true,
  updatedAt: true,
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
  createdAt: true,
}).extend({
  details: z.unknown().optional(),
  userId: z.string().optional(),
  userName: z.string().optional(),
  serverId: z.string().optional(),
  channelId: z.string().optional(),
});

// Types
export type Key = typeof keys.$inferSelect;
export type InsertKey = z.infer<typeof insertKeySchema>;

export type Role = typeof roles.$inferSelect;
export type InsertRole = z.infer<typeof insertRoleSchema>;

export type Setting = typeof settings.$inferSelect;
export type InsertSetting = z.infer<typeof insertSettingSchema>;

export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;

// Key types
export const keyTypes = ["day", "week", "month", "3month", "6month", "lifetime", "custom"] as const;
export type KeyType = typeof keyTypes[number];

// Permission interface
export interface RolePermissions {
  day: boolean;
  week: boolean;
  month: boolean;
  "3month": boolean;
  "6month": boolean;
  lifetime: boolean;
  custom: boolean;
}

// Bot status interface
export interface BotStatus {
  online: boolean;
  uptime: number;
  serverCount: number;
  latency: number;
  lastStarted?: Date;
}

// Statistics interface
export interface DashboardStats {
  totalKeys: number;
  todayGenerated: number;
  activeRoles: number;
  uptime: string;
  totalAvailable: number;
  usedToday: number;
  addedToday: number;
  keyPools: Record<KeyType, number>;
}
